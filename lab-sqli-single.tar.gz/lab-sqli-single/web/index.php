<?php
// Homepage - Lab SQLi
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab SQLi - Belajar SQL Injection</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>

<nav class="navbar">
    <a class="brand" href="/">🔐 Lab<span>SQLi</span></a>
    <div class="nav-links">
        <a href="/" class="active">Home</a>
        <a href="/basic/">Basic</a>
        <a href="/auth/">Auth Bypass</a>
        <a href="/blind/">Blind SQLi</a>
    </div>
</nav>

<div class="page-header">
    <h1>🎯 SQL Injection Lab</h1>
    <p>Lab praktik SQL Injection dalam satu web — untuk tujuan edukasi keamanan</p>
    <p style="margin-top:8px; color:#e94560; font-size:0.8rem;">⚠️ FOR EDUCATIONAL USE ONLY — Gunakan hanya di environment lab yang terisolasi</p>
</div>

<div class="container">

    <div class="lab-box" style="margin-top:0;">
        <h2>📋 Tentang Lab Ini</h2>
        <p style="color:#aaa; font-size:0.9rem; line-height:1.7;">
            Lab ini dirancang untuk membantu kamu memahami SQL Injection dari dasar hingga teknik yang lebih kompleks.
            Setiap modul memiliki tingkat kesulitan yang berbeda. Baca hint jika kamu stuck, dan perhatikan
            query SQL yang ditampilkan untuk memahami apa yang terjadi di balik layar.
        </p>
    </div>

    <div class="modules-grid">

        <!-- Modul 1: Basic SQLi -->
        <a href="/basic/" class="module-card basic">
            <div class="badge badge-easy">🟢 EASY</div>
            <h2>1. Basic SQL Injection</h2>
            <p>Pelajari dasar SQL injection dengan mengeksploitasi query pencarian produk. Tidak ada filtering sama sekali.</p>
            <ul style="margin: 10px 0 0 18px; font-size:0.82rem; color:#888;">
                <li>Error-based SQLi</li>
                <li>UNION-based SQLi</li>
                <li>Ekstrak data dari tabel lain</li>
            </ul>
            <span class="go-btn">Mulai Modul →</span>
        </a>

        <!-- Modul 2: Auth Bypass -->
        <a href="/auth/" class="module-card auth">
            <div class="badge badge-medium">🟡 MEDIUM</div>
            <h2>2. Auth Bypass + Filtering</h2>
            <p>Bypass form login menggunakan SQL injection. Ada filtering sederhana yang perlu kamu bypass.</p>
            <ul style="margin: 10px 0 0 18px; font-size:0.82rem; color:#888;">
                <li>Login bypass klasik</li>
                <li>Bypass filter komentar</li>
                <li>Comment-based bypass</li>
            </ul>
            <span class="go-btn">Mulai Modul →</span>
        </a>

        <!-- Modul 3: Blind SQLi -->
        <a href="/blind/" class="module-card blind">
            <div class="badge badge-hard">🔴 HARD</div>
            <h2>3. Blind / Logic-Based SQLi</h2>
            <p>Tidak ada error output. Gunakan teknik boolean-based dan time-based blind injection.</p>
            <ul style="margin: 10px 0 0 18px; font-size:0.82rem; color:#888;">
                <li>Boolean-based blind</li>
                <li>Time-based blind</li>
                <li>Manual data extraction</li>
            </ul>
            <span class="go-btn">Mulai Modul →</span>
        </a>

    </div>

    <!-- Cheat Sheet Box -->
    <div class="lab-box" style="margin-top:30px;">
        <h2>📖 Quick Reference</h2>
        <div style="display:grid; grid-template-columns: repeat(auto-fit, minmax(250px,1fr)); gap:15px; margin-top:10px;">
            <div>
                <p style="color:#a8ff78; font-size:0.8rem; margin-bottom:6px;">KOMENTAR SQL</p>
                <div class="query-display" style="margin:0;">-- komentar satu baris<br># komentar MySQL<br>/* komentar blok */</div>
            </div>
            <div>
                <p style="color:#f7971e; font-size:0.8rem; margin-bottom:6px;">ALWAYS TRUE</p>
                <div class="query-display" style="margin:0;">1=1<br>'a'='a'<br>1 OR 1=1</div>
            </div>
            <div>
                <p style="color:#e94560; font-size:0.8rem; margin-bottom:6px;">UNION SKELETON</p>
                <div class="query-display" style="margin:0;">' UNION SELECT 1,2,3-- -<br>' UNION SELECT null,null,null-- -</div>
            </div>
        </div>
    </div>

</div>

<footer>
    Lab SQLi — <span>Hanya untuk keperluan edukasi</span> — Jangan gunakan di sistem tanpa izin
</footer>

</body>
</html>
