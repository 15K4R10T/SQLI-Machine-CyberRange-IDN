<?php
// auth/index.php — Modul 2: Auth Bypass + Filtering Sederhana

require_once '../includes/db.php';

$conn = getDB();
$message = '';
$message_type = '';
$query_shown = '';
$level = isset($_GET['level']) ? (int)$_GET['level'] : 1;

function simpleFilter($input, $level) {
    if ($level >= 2) {
        // Level 2: filter tanda -- dan #
        $input = str_replace(['--', '#'], '', $input);
    }
    if ($level >= 3) {
        // Level 3: filter juga OR/AND (case insensitive)
        $input = preg_replace('/\bOR\b|\bAND\b/i', '', $input);
    }
    return $input;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Terapkan filter sesuai level
    $username_filtered = simpleFilter($username, $level);
    $password_filtered = simpleFilter($password, $level);

    // ❌ VULNERABLE: String concatenation
    $query = "SELECT id, username, role, secret FROM users WHERE username='$username_filtered' AND password='$password_filtered'";
    $query_shown = "SELECT id, username, role, secret FROM users WHERE username='$username' AND password='$password'";

    if ($level > 1) {
        $query_shown .= "\n[Setelah filter L{$level}]: username='$username_filtered' AND password='$password_filtered'";
    }

    $result = $conn->query($query);

    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        $message = "✅ Login berhasil! Selamat datang, <strong>{$user['username']}</strong> (role: {$user['role']})";
        if ($user['role'] === 'admin') {
            $message .= "<br><br>🚩 FLAG: <code>{$user['secret']}</code>";
        }
        $message_type = 'success';
    } else {
        $error_detail = $conn->error ? ' — Error: ' . $conn->error : '';
        $message = "❌ Username atau password salah.$error_detail";
        $message_type = 'danger';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Auth Bypass — Lab SQLi</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>

<nav class="navbar">
    <a class="brand" href="/">🔐 Lab<span>SQLi</span></a>
    <div class="nav-links">
        <a href="/">Home</a>
        <a href="/basic/">Basic</a>
        <a href="/auth/" class="active">Auth Bypass</a>
        <a href="/blind/">Blind SQLi</a>
    </div>
</nav>

<div class="page-header">
    <h1>🔑 Modul 2 — Auth Bypass + Filtering</h1>
    <p>Bypass form login menggunakan SQL injection. Setiap level memiliki filtering yang berbeda.</p>
</div>

<div class="lab-container">

    <!-- Level Selector -->
    <div class="lab-box">
        <h2>⚙️ Pilih Level</h2>
        <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <?php for ($i = 1; $i <= 3; $i++): ?>
            <a href="/auth/?level=<?= $i ?>"
               style="padding:10px 20px; border-radius:6px; text-decoration:none; font-weight:bold;
                      <?= $level == $i ? 'background:#e94560; color:white;' : 'background:#1a1a2e; color:#aaa; border:1px solid #444;' ?>">
                Level <?= $i ?>
                <?php if ($i==1) echo '<span style="font-size:0.75rem; margin-left:5px;">— No Filter</span>';
                      elseif ($i==2) echo '<span style="font-size:0.75rem; margin-left:5px;">— Filter --/#</span>';
                      else echo '<span style="font-size:0.75rem; margin-left:5px;">— Filter OR/AND</span>'; ?>
            </a>
            <?php endfor; ?>
        </div>

        <div style="margin-top:15px; font-size:0.85rem; color:#aaa;">
            <?php if ($level == 1): ?>
            <div class="alert alert-info">Level 1: Tidak ada filtering. Gunakan teknik bypass paling dasar.</div>
            <?php elseif ($level == 2): ?>
            <div class="alert alert-warning">Level 2: Karakter <code>--</code> dan <code>#</code> dihapus. Temukan cara lain untuk mengakhiri query!</div>
            <?php else: ?>
            <div class="alert alert-danger">Level 3: <code>--</code>, <code>#</code>, <code>OR</code>, <code>AND</code> dihapus. Gunakan teknik yang lebih kreatif.</div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Login Form -->
    <div class="lab-box">
        <h2>🔐 Form Login</h2>
        <form method="POST" action="/auth/?level=<?= $level ?>">
            <div class="form-group">
                <label>Username:</label>
                <input type="text" name="username"
                       value="<?= sanitize($_POST['username'] ?? '') ?>"
                       placeholder="masukkan username atau payload">
            </div>
            <div class="form-group">
                <label>Password:</label>
                <input type="text" name="password"
                       value="<?= sanitize($_POST['password'] ?? '') ?>"
                       placeholder="masukkan password atau payload">
            </div>
            <button type="submit" class="btn btn-primary">Login</button>
        </form>
    </div>

    <?php if ($query_shown): ?>
    <div class="lab-box">
        <h2>🔬 Query yang Dieksekusi</h2>
        <div class="query-display" style="white-space:pre-wrap;"><?= sanitize($query_shown) ?></div>
    </div>
    <?php endif; ?>

    <?php if ($message): ?>
    <div class="alert alert-<?= $message_type ?>">
        <?= $message ?>
    </div>
    <?php endif; ?>

    <!-- Hints per level -->
    <div class="lab-box">
        <h2>💡 Hints — Level <?= $level ?></h2>

        <?php if ($level == 1): ?>
        <details class="hint-box">
            <summary>Hint 1 — Struktur query</summary>
            <p>Query aslinya: <code>SELECT ... WHERE username='INPUT' AND password='INPUT'</code><br>
            Kamu perlu membuat kondisi menjadi TRUE dan menghapus sisa query.</p>
        </details>
        <details class="hint-box" style="margin-top:10px;">
            <summary>Hint 2 — Payload klasik</summary>
            <p>Coba di kolom username: <code>admin'-- -</code> (password bebas)<br>
            Atau: <code>' OR 1=1-- -</code><br>
            Query akan menjadi: <code>WHERE username='' OR 1=1-- -' AND password='...'</code></p>
        </details>

        <?php elseif ($level == 2): ?>
        <details class="hint-box">
            <summary>Hint 1 — -- dihapus, bagaimana?</summary>
            <p>Jika <code>--</code> dihapus, coba comment style lain. MySQL mendukung: <code>/*</code><br>
            Payload: <code>admin'/*</code> ... tapi ini juga perlu diakhiri.<br>
            Coba: <code>' OR '1'='1</code> — ini menutup quote tanpa perlu komentar!</p>
        </details>
        <details class="hint-box" style="margin-top:10px;">
            <summary>Hint 2 — Always true tanpa komentar</summary>
            <p>Username: <code>anything</code><br>
            Password: <code>' OR '1'='1</code><br>
            Query: <code>WHERE username='anything' AND password='' OR '1'='1'</code></p>
        </details>

        <?php else: ?>
        <details class="hint-box">
            <summary>Hint 1 — OR dihapus juga!</summary>
            <p>Coba karakter bypass OR: <code>||</code> (pipe double) yang bekerja sebagai OR di MySQL dengan mode tertentu.<br>
            Atau manipulasi kondisi menggunakan nilai yang selalu benar.</p>
        </details>
        <details class="hint-box" style="margin-top:10px;">
            <summary>Hint 2 — Pendekatan berbeda</summary>
            <p>Jika username yang diketahui adalah 'admin', coba masukkan password yang benar secara langsung,<br>
            atau gunakan: username=<code>admin</code> dan password=<code>admin123</code><br>
            Atau pikirkan: apakah ada cara membuat WHERE clause true hanya dengan manipulasi string?</p>
        </details>
        <?php endif; ?>

    </div>

</div>

<footer>
    Lab SQLi — <span>Hanya untuk keperluan edukasi</span>
</footer>

</body>
</html>
