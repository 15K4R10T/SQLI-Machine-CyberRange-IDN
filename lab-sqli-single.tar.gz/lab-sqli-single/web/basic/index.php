<?php
// basic/index.php — Modul 1: Basic SQL Injection (NO filtering)

require_once '../includes/db.php';

$conn = getDB();
$results = [];
$query_shown = '';
$error = '';
$search = '';

if (isset($_GET['search'])) {
    $search = $_GET['search'];

    // ❌ VULNERABLE: Input langsung dimasukkan ke query tanpa sanitasi
    $query = "SELECT id, name, description, price, category FROM products WHERE name LIKE '%$search%'";
    $query_shown = $query;

    $result = $conn->query($query);

    if ($result === false) {
        $error = $conn->error;
    } elseif ($result !== true) {
        while ($row = $result->fetch_assoc()) {
            $results[] = $row;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Basic SQLi — Lab SQLi</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>

<nav class="navbar">
    <a class="brand" href="/">🔐 Lab<span>SQLi</span></a>
    <div class="nav-links">
        <a href="/">Home</a>
        <a href="/basic/" class="active">Basic</a>
        <a href="/auth/">Auth Bypass</a>
        <a href="/blind/">Blind SQLi</a>
    </div>
</nav>

<div class="page-header">
    <h1>📦 Modul 1 — Basic SQL Injection</h1>
    <p>Cari produk di toko. Input kamu langsung masuk ke query SQL tanpa filtering apapun.</p>
</div>

<div class="lab-container">

    <!-- Objective -->
    <div class="lab-box">
        <h2>🎯 Objektif</h2>
        <ol style="margin-left:20px; font-size:0.88rem; color:#aaa; line-height:1.8;">
            <li>Konfirmasi adanya SQL injection (gunakan <code style="color:#a8ff78">'</code>)</li>
            <li>Cari tahu jumlah kolom query asli</li>
            <li>Tampilkan semua produk termasuk yang tersembunyi</li>
            <li>Gunakan UNION untuk membaca tabel <code style="color:#a8ff78">users</code></li>
            <li>Ekstrak kolom <code style="color:#a8ff78">secret</code> dari tabel users</li>
        </ol>
    </div>

    <!-- Search Form -->
    <div class="lab-box">
        <h2>🔍 Pencarian Produk</h2>
        <form method="GET" action="/basic/">
            <div class="form-group">
                <label>Nama Produk:</label>
                <input type="text" name="search"
                       value="<?= sanitize($search) ?>"
                       placeholder="cari produk... atau coba payload SQLi">
            </div>
            <button type="submit" class="btn btn-primary">Cari</button>
            <a href="/basic/" style="margin-left:10px; color:#666; font-size:0.85rem;">Reset</a>
        </form>
    </div>

    <?php if ($query_shown): ?>
    <!-- SQL Query yang dieksekusi -->
    <div class="lab-box">
        <h2>🔬 Query yang Dieksekusi</h2>
        <div class="query-display">
            <div class="label">SQL:</div>
            <?= sanitize($query_shown) ?>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($error): ?>
    <!-- Error Output — berguna untuk error-based SQLi -->
    <div class="alert alert-danger">
        <strong>⚠️ Database Error:</strong><br>
        <?= sanitize($error) ?>
    </div>
    <?php endif; ?>

    <?php if (!empty($results)): ?>
    <!-- Hasil Query -->
    <div class="lab-box">
        <h2>📊 Hasil (<?= count($results) ?> baris)</h2>
        <table class="result-table">
            <thead>
                <tr>
                    <?php foreach (array_keys($results[0]) as $col): ?>
                    <th><?= sanitize($col) ?></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($results as $row): ?>
                <tr>
                    <?php foreach ($row as $val): ?>
                    <td><?= sanitize((string)$val) ?></td>
                    <?php endforeach; ?>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php elseif (isset($_GET['search']) && !$error): ?>
    <div class="alert alert-warning">Tidak ada produk ditemukan.</div>
    <?php endif; ?>

    <!-- HINTS -->
    <div class="lab-box">
        <h2>💡 Hints</h2>

        <details class="hint-box">
            <summary>Hint 1 — Konfirmasi SQLi</summary>
            <p>Coba masukkan tanda kutip tunggal: <code>'</code> — jika muncul error database, berarti vulnerable!<br>
            Lalu coba: <code>Laptop' OR '1'='1</code> untuk melihat lebih banyak hasil.</p>
        </details>

        <details class="hint-box" style="margin-top:10px;">
            <summary>Hint 2 — Hitung jumlah kolom</summary>
            <p>Gunakan ORDER BY untuk menentukan jumlah kolom:<br>
            <code>a' ORDER BY 1-- -</code><br>
            <code>a' ORDER BY 2-- -</code><br>
            Terus tambah angkanya sampai muncul error. Jika error di angka 6, berarti ada 5 kolom.</p>
        </details>

        <details class="hint-box" style="margin-top:10px;">
            <summary>Hint 3 — UNION SELECT</summary>
            <p>Setelah tahu jumlah kolom (5), gunakan UNION:<br>
            <code>a' UNION SELECT 1,2,3,4,5-- -</code><br>
            Perhatikan angka mana yang muncul di output — itu posisi yang bisa diisi data.</p>
        </details>

        <details class="hint-box" style="margin-top:10px;">
            <summary>Hint 4 — Baca tabel users</summary>
            <p>Ganti angka dengan nama kolom dari tabel users:<br>
            <code>a' UNION SELECT id,username,password,email,secret FROM users-- -</code></p>
        </details>

    </div>

</div>

<footer>
    Lab SQLi — <span>Hanya untuk keperluan edukasi</span>
</footer>

</body>
</html>
