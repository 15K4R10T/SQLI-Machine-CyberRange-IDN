#!/bin/bash
# entrypoint.sh — Init MySQL lalu start semua service via supervisor

set -e

echo "🚀 Starting Lab SQLi single container..."

# ── Init MySQL jika belum ada ─────────────────
if [ ! -d "/var/lib/mysql/labsqli" ]; then
    echo "📦 Initializing MySQL database..."

    # Start MySQL sementara untuk init
    mysqld_safe --skip-networking &
    MYSQL_PID=$!

    # Tunggu MySQL siap
    for i in $(seq 1 30); do
        if mysqladmin ping --silent 2>/dev/null; then
            break
        fi
        echo "   Waiting for MySQL... ($i/30)"
        sleep 1
    done

    # Buat user dan database
    mysql -u root <<-EOSQL
        CREATE DATABASE IF NOT EXISTS labsqli CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
        CREATE USER IF NOT EXISTS 'labuser'@'localhost' IDENTIFIED BY 'labpass123';
        GRANT ALL PRIVILEGES ON labsqli.* TO 'labuser'@'localhost';
        ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'rootpass123';
        FLUSH PRIVILEGES;
EOSQL

    # Import data
    mysql -u root -prootpass123 labsqli < /docker-entrypoint-initdb.sql

    echo "✅ Database initialized!"

    # Stop MySQL sementara
    mysqladmin -u root -prootpass123 shutdown 2>/dev/null || kill $MYSQL_PID 2>/dev/null
    wait $MYSQL_PID 2>/dev/null || true
    sleep 2
fi

echo "🎯 Starting all services via supervisor..."

# Start supervisor (mengelola Apache + MySQL)
exec /usr/bin/supervisord -n -c /etc/supervisor/conf.d/supervisord.conf
